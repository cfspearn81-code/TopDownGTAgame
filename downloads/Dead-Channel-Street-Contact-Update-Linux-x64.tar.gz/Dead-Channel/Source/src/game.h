#ifndef DC_H
#define DC_H
typedef unsigned int U;
enum{W=960,H=540};
enum{UP=1,DOWN=2,LEFT=4,RIGHT=8,USE=16,FIRE=32,BRAKE=64,ESC=128,MAP=256,SAVE=512,ENTER=1024,HELP=2048,GFX=4096,SLOT=8192,NEW_SLOT=16384,PUNCH=32768,TAXI_NEXT=65536,DELETE_SLOT=131072,ACTIVITIES=262144,PHONE=524288,PHONE_ALT=1048576,CAMERA=2097152,LOADOUT=4194304,ATLAS_WORLD=8388608,WHEEL=16777216,USE_PATCH=33554432,TAXI_QUOTE=1u<<26,TAXI_RECEIPT=1u<<27};
extern U pixels[W*H];
void init_city(void);
void tick(U keys);
void clear_input(void);
void set_session_seed(U seed);
void pointer_input(int sx,int sy,U clicks);
void text_input(U ch);
void paint(void);
void frame_probe_banner(const char *label,U ink);
int take_radio_record(void);
int night_music_track(void);
int exit_save_ok(void);
int take_phone_link(void);
void phone_link_result(int ok);
int get_scene(void);
void request_save(void);
void load_save(void);
#endif
