/* Linux compatibility smoke harness: map the exact PE image and drive its
 * real entrypoint with stubbed Win32 services. This is not a Windows test. */
#define _GNU_SOURCE
#include <sys/mman.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <setjmp.h>
typedef uint64_t Q;typedef uint32_t D;typedef uint16_t S;
typedef struct{int l,t,r,b;}Rect;
typedef struct {void *w;D msg;Q wp;Q lp;D time;int x,y;D unused;}Msg;
static int frame, saved, volume, delivered, menuFrame, safeWrites;static jmp_buf jb;
static Q ms;static unsigned checksum,previous;static const char *loadCareer,*saveCareer;static int readCareer,opening,pointerScenario,pointerStage,pointerPx,pointerPy,clearedPx,createStage,creates;
static int deleteTest,deleteStage,deleteCalls,atmTest;
static unsigned fsz[252],offset;static unsigned char vdisk[252][1024],pending[1024];static unsigned psize;static D status;static unsigned beforePin,afterPin,afterClear;
#define A __attribute__((ms_abi))
typedef int64_t (A *HostProc)(void*,D,Q,int64_t);static HostProc winproc;
static Q A ok(void){return 1;}
static Q A nil(void){return 0;}
/* The optional street tour streams (tick count, key mask) pairs. */
static int tourFrames,tourHold;
static unsigned tourMask,tourSaveHash;
static void next_tour_keys(void){
 if(!tourHold)assert(scanf("%d %u",&tourHold,&tourMask)==2&&tourHold>0);
 tourHold--;
}
static Q A key(int k){
 if(tourFrames){
  static const struct {int key;unsigned bit;} bindings[]={
   {'W',1},{'S',2},{'A',4},{'D',8},{'E',16},{0x20,32},{0x10,64},
   {0x1b,128},{'M',256},{0x74,512},{13,1024},{0x70,2048},{0x71,4096},
   {0x72,8192},{0x73,16384},{'X',32768},{'T',65536},{0x2e,131072}
  };
  for(unsigned i=0;i<sizeof bindings/sizeof *bindings;i++)
   if(bindings[i].key==k)return (tourMask&bindings[i].bit)?0x8000:0;
  return 0;
 }
 if(atmTest)return ((k==13&&(frame==2||frame==7||frame==14))||
  (k=='E'&&frame==4)||(k==0x28&&frame==10)||(k==0x25&&frame==12)||
  (k==0x1b&&frame==16)||(k==0x74&&frame==20))?0x8000:0;
 if(deleteTest)return ((k==0x28&&frame==1)||(k==0x2e&&frame==3)||(k==13&&(frame==6||frame==20))||(k==0x74&&frame==62))?0x8000:0;
 if(pointerScenario)return ((k==13&&frame==1)||(k=='M'&&(frame==5||frame==50))||(k==0x74&&frame==66))?0x8000:0;
 if(loadCareer&&opening!=2){
  return ((k==13&&frame==2)||(k=='D'&&frame>15&&frame<57)||(k==0x74&&frame==62))?0x8000:0;
 }
 if((k==13&&(frame==1||frame==6||frame==11))||(k==0x73&&opening==2&&frame==1)||
    (k=='S'&&frame>=14&&frame<=63)||(k=='E'&&frame==65)||(k==0x74&&frame==70))return 0x8000;
 return 0;
}
static void A die(D code){assert(frame==(tourFrames?tourFrames:75)&&code==0);longjmp(jb,1);}
static Q A ticks(void){
 if(tourFrames){
  /* Seed 17, then one 60 Hz simulation tick per host loop. */
  if(ms++<2)return 17;
  return 17+((ms-2)*1000+59)/60;
 }
 ms+=17;return ms;
}
static int A peek(Msg*m,void*w,D a,D b,D c){
 if(tourFrames){
  if(frame<tourFrames)return 0;
  memset(m,0,sizeof *m);m->msg=0x12;return 1;
 }
 if(deleteTest&&((frame==9&&deleteStage==0)||(frame==13&&deleteStage==1))){
   memset(m,0,sizeof *m);m->w=(void*)1;m->msg=0x0201;
   m->lp=deleteStage++==0?790+(460<<16):590+(332<<16);return 1;
 }
 if(pointerScenario&&((frame==12&&pointerStage==0)||(frame==30&&pointerStage==1))){
   memset(m,0,sizeof *m);m->w=(void*)1;m->msg=pointerStage++==0?0x0201:0x0204;
   int ww=pointerScenario==2?1920:1300,hh=pointerScenario==2?1080:790,vy=(hh-ww*540/960)/2;
   const int sx=610,sy=334;int x=(sx*ww+959)/960,y=vy+(sy*(ww*540/960)+539)/540;
   m->lp=(unsigned)x+((unsigned)y<<16);return 1;
 }
 if(!pointerScenario&&(!loadCareer||opening==2)&&((frame==3&&createStage==0)||(frame==5&&createStage<5)||(frame==8&&createStage==5))){
   memset(m,0,sizeof *m);m->w=(void*)1;
   if(createStage==0){m->msg=0x0201;m->lp=566+(151<<16);}
   else if(createStage<=4){m->msg=0x0102;m->wp="QA: "[createStage-1];}
   else{m->msg=0x0201;m->lp=578+(175<<16);}
   createStage++;return 1;
 }
 if(frame<75)return 0;memset(m,0,sizeof *m);m->msg=0x12;return 1;
}
static int A rect(void*w,Rect*r){*r=pointerScenario==2?(Rect){0,0,1920,1080}:pointerScenario?(Rect){0,0,1300,790}:(Rect){0,0,960,540};return 1;}
static Q A regcls(void*k){memcpy(&winproc,(char*)k+8,sizeof winproc);return 1;}
static int64_t A dispatchMsg(Msg*m){assert(winproc);return winproc(m->w,m->msg,m->wp,m->lp);}
static int pathslot(const S*p){
 assert(p&&*p=='.');
 while(*p&&*p!='c'&&*p!='o'&&*p!='f')p++;
 if(*p=='c')return 0;if(*p=='o')return 1;
 assert(*p=='f');return 1+100*(p[6]-'0')+10*(p[7]-'0')+p[8]-'0';
}
/* Isolated stage must be carried unchanged through close and commit. */
static S stageName[1024];
static Q A openfile(const S*p,D access,D share,void*sec,D mode,D attr,void*t){
 if(mode==1){
  assert(access==0x40000000u&&!share&&!stageName[0]);int n=0;
  do{assert(n<1024);stageName[n]=p[n];}while(p[n++]);
  psize=0;return 400;
 }
 int i=pathslot(p);assert(i>=0&&i<252);
 assert(mode==3&&share==5);offset=0;
 if(fsz[i])return i+1;
 status=2;return UINT64_MAX;
}
static int A removefile(const S*p){assert(deleteTest&&frame==13&&pathslot(p)==2&&fsz[0]&&fsz[2]&&!deleteCalls);fsz[2]=0;deleteCalls++;return 1;}
static Q A errorcode(void){return status;}
static int A readfile(void*h,void*p,D n,D*g,void*over){
 unsigned i=(unsigned)((uintptr_t)h-1);assert(i<252&&offset<=fsz[i]);
 *g=n<fsz[i]-offset?n:fsz[i]-offset;memcpy(p,vdisk[i]+offset,*g);offset+=*g;readCareer=1;return 1;
}
static int A writefile(void*h,const void*p,D n,D*g,void*over){
 assert((uintptr_t)h==400&&n>=128&&n<1024&&*(const D*)p==0x44433131);
 memcpy(pending,p,n);psize=*g=n;saved++;return 1;
}
static int A replace(const S*a,const S*b,D f){
 int i=pathslot(b);assert(a!=b&&(f&8)&&psize&&stageName[0]);
 int k=0;do{assert(stageName[k]==a[k]);}while(a[k++]);stageName[0]=0;
 if(!(f&1)){assert(!fsz[i]);if(opening==2&&loadCareer)assert(i==2);creates++;}
 memcpy(vdisk[i],pending,psize);fsz[i]=psize;
 if(saveCareer){FILE*fp=fopen(saveCareer,"wb");assert(fp&&fwrite(pending,1,psize,fp)==psize);fclose(fp);}
 safeWrites++;return 1;
}
static int A draw(void*dc,int x,int y,int w,int h,int sx,int sy,int sw,int sh,const D *b,const void*fmt,D palette,D op){
 assert(sw==960&&sh==540&&op==0xcc0020);
 if(pointerScenario==2)assert(x==0&&y==0&&w==1920&&h==1080);
 else if(pointerScenario)assert(x==0&&y==29&&w==1300&&h==731);
 else assert(w==960&&h==540);
 frame++;
 if(atmTest&&frame==6)assert(b[96*960+193]==0x8cece0u); /* ATM mint title strip */
 if(tourFrames){if(frame<tourFrames)next_tour_keys();return sh;}
 checksum=2166136261u;for(int i=0;i<960*540;i+=23)checksum=(checksum^b[i])*16777619u;
 if(previous!=checksum)volume++;previous=checksum;
 if(pointerScenario){
   const int pinx=610,piny=334;unsigned t=b[piny*960+pinx];int purple=0;
   for(int yy=70;yy<450;yy++)for(int xx=270;xx<685;xx++)if(b[yy*960+xx]==0xc68aff||b[yy*960+xx]==0xe4c8f8)purple++;
   if(frame==11){beforePin=checksum;pointerPx=purple;}
   if(frame==25){afterPin=checksum;pointerPy=purple;}
   if(frame==45){afterClear=checksum;clearedPx=purple;}
 }
 if(frame==7)menuFrame=checksum;if(frame==43)delivered=(checksum!=(unsigned)menuFrame);
 return sh;
}
typedef struct{char*n;void*p;}Bind;
static const Bind bind[]={
 {"ExitProcess",die},{"GetTickCount64",ticks},{"GetEnvironmentVariableW",nil},{"GetAsyncKeyState",key},{"PeekMessageW",peek},
 {"GetClientRect",rect},{"CreateFileW",openfile},{"WriteFile",writefile},{"MoveFileExW",replace},{"DeleteFileW",removefile},{"StretchDIBits",draw},
 {"GetCurrentProcessId",ok},{"GetLastError",errorcode},{"PatBlt",ok},{"TrackMouseEvent",ok},{"GetModuleHandleW",ok},{"Sleep",nil},{"CreateDirectoryW",ok},{"ReadFile",readfile},{"CloseHandle",ok},{"RegisterClassExW",regcls},
 {"CreateWindowExW",ok},{"DefWindowProcW",nil},{"ShowWindow",ok},{"TranslateMessage",ok},{"DispatchMessageW",dispatchMsg},
 {"GetDC",ok},{"ReleaseDC",ok},{"LoadCursorW",ok},{"PostQuitMessage",nil},{"SetProcessDPIAware",ok},{"GetForegroundWindow",ok}
};
static D d(const unsigned char*a,size_t p){D x;memcpy(&x,a+p,4);return x;}static S s(const unsigned char*a,size_t p){S x;memcpy(&x,a+p,2);return x;}static Q q(const unsigned char*a,size_t p){Q x;memcpy(&x,a+p,8);return x;}
int main(int argc,char**argv){assert(argc>=2&&argc<=4);const char *mode=getenv("DC_OPENING");opening=mode?atoi(mode):0;mode=getenv("DC_POINTER");pointerScenario=mode?atoi(mode):0;deleteTest=getenv("DC_DELETE")!=0;atmTest=getenv("DC_ATM_TEST")!=0;if(argc==3&&!strcmp(argv[2],"--tour")){
 assert(scanf("%d %x",&tourFrames,&tourSaveHash)==2&&tourFrames>0);
 next_tour_keys();
 }else if(argc>=3&&strcmp(argv[2],"-"))loadCareer=argv[2];if(argc==4)saveCareer=argv[3];
 if(loadCareer){int i=opening==1?1:0;FILE*fixture=fopen(loadCareer,"rb");assert(fixture);fsz[i]=fread(vdisk[i],1,sizeof vdisk[i],fixture);assert(fsz[i]>0&&fsz[i]<sizeof vdisk[i]);fclose(fixture);}
 if(deleteTest){assert(fsz[0]);fsz[2]=fsz[0];memcpy(vdisk[2],vdisk[0],fsz[2]);}
 FILE*f=fopen(argv[1],"rb");assert(f);fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);unsigned char*file=malloc(n);assert(file&&fread(file,1,n,f)==(size_t)n);fclose(f);
 D pe=d(file,60),opt=pe+24;assert(d(file,pe)==0x4550&&s(file,pe+4)==0x8664&&s(file,opt)==0x20b);
 Q base=q(file,opt+24);D size=d(file,opt+56);unsigned char*img=mmap((void*)base,size,PROT_READ|PROT_WRITE|PROT_EXEC,MAP_ANONYMOUS|MAP_PRIVATE|MAP_FIXED_NOREPLACE,-1,0);assert(img==(void*)base);
 D o=opt+s(file,pe+20);for(int i=0;i<s(file,pe+6);i++,o+=40){D vs=d(file,o+8),rva=d(file,o+12),raw=d(file,o+16),off=d(file,o+20);assert(rva+vs<=size&&off+raw<=(Q)n);if(raw)memcpy(img+rva,file+off,raw);}
 D imp=d(file,opt+120);assert(imp);for(D t=imp;d(img,t);t+=20){D lookup=d(img,t),iat=d(img,t+16);for(int i=0;q(img,lookup+i*8);i++){const char*name=(const char*)img+q(img,lookup+i*8)+2;void*fn=0;for(int j=0;j<(int)(sizeof bind/sizeof *bind);j++)if(!strcmp(name,bind[j].n))fn=bind[j].p;if(!fn)fprintf(stderr,"Unmapped import: %s\n",name);assert(fn);memcpy(img+iat+i*8,&fn,8);}}
 if(!setjmp(jb)){typedef void (A *WinEntry)(void);WinEntry start=(WinEntry)(img+d(file,opt+16));start();assert(!"PE entrypoint returned unexpectedly");}
 assert(saved>0&&safeWrites==saved&&(!loadCareer||readCareer));
 if(tourFrames){
  assert(fsz[0]>=4);
  D actual=d(vdisk[0],fsz[0]-4);
  printf("Street tour: %d frames, %d atomic writes, final save %08x (expected %08x).\n",frame,safeWrites,actual,tourSaveHash);
  assert(creates==1&&actual==tourSaveHash&&!tourHold);
  return 0;
 }
 if(atmTest){
  assert(!creates&&safeWrites==3&&fsz[0]==304&&d(vdisk[0],4)==10);
  assert(d(vdisk[0],8)==250&&d(vdisk[0],136)==900&&d(vdisk[0],288)==100&&d(vdisk[0],292)==0&&d(vdisk[0],296)==0);
  puts("ATM PE entry point: E opened, deposited $100, withdrew $50, exited, saved.");
  return 0;
 }
 if(deleteTest){assert(deleteStage==2&&deleteCalls==1&&fsz[0]&&!fsz[2]&&!creates);puts("Native entrypoint: cancel, confirm, exact slot deleted, other slot still loads and saves.");return 0;}
 if(!loadCareer||opening==2){assert(creates==1&&createStage==6&&saved>=2);
   int slot=opening==2&&loadCareer?2:0;
   assert(fsz[slot]==304&&d(vdisk[slot],4)==10&&!memcmp(vdisk[slot]+268,"Vanta LocalQA:",14));
 }else assert(!creates);
 if(pointerScenario){assert(pointerStage==2&&beforePin!=afterPin&&afterPin!=afterClear&&pointerPy>pointerPx&&clearedPx==pointerPx);printf("Pointer clicks map correctly at %s render size.\n",pointerScenario==2?"1920x1080":"1300x790 letterboxed");}
 else assert(volume>5&&delivered);printf("Exact Windows x64 EXE: 75 frames via native entry, menu input, walking, frame output, and atomic save call verified against Win32 stubs.\n");
}
